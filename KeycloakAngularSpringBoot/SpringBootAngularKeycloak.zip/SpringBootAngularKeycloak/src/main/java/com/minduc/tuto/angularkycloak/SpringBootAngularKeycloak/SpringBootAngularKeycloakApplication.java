package com.minduc.tuto.angularkycloak.SpringBootAngularKeycloak;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootAngularKeycloakApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootAngularKeycloakApplication.class, args);
	}

}
